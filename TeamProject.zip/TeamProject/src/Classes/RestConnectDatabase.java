package Classes;
import java.sql.*;

public class RestConnectDatabase {

	public static void main(String args[]){  
		try{  
			
			
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection(  
		"jdbc:mysql://localhost:3306/Fast_Food","root","password");  
		//here sonoo is database name, root is username and password  
		Statement stmt=con.createStatement();  
		//stmt.executeUpdate("INSERT INTO product " + "VALUES (37, 'Smo', 2.00, null, type)");
		ResultSet rs=stmt.executeQuery("select * from product WHERE Type = 'Drink' ");  
		//ResultSet rs=stmt.executeQuery("select * from product WHERE Type = 'Main' "); 
		// insert the data
		while(rs.next())  
		System.out.println("  "+rs.getString(2)+"  "+rs.getString(3));  
		con.close();  
		}catch(Exception e){ System.out.println(e);}  
		}  
		}  

